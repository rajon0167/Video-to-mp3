# Video to Audio Converter

Simple Node.js app to extract audio (MP3) from video files.

## Install
```bash
npm install
```

## Run
```bash
node server.js
```

Open http://localhost:3000 and upload a video file to convert.
